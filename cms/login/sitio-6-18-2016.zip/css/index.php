<?php
  Header( "HTTP/1.1 301 Moved Permanently" );
  Header( "Location: http://kayrosstudio.com/consolidacion/" );
?>